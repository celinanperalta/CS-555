# Setup
```
cd gedcom/project04
pip install -r requirements.txt
```
# How to Run
```
cd gedcom/project04/src
chmod u+x main.py
python main.py --file <filename>
```
# Testing
```
cd gedcom/project04
pytest
```